﻿namespace FilosofosQueJantam
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.filosofo1GE = new System.Windows.Forms.Label();
            this.filosofo1GD = new System.Windows.Forms.Label();
            this.filosofo1TE = new System.Windows.Forms.Label();
            this.filosofo1TD = new System.Windows.Forms.Label();
            this.filosofo2GE = new System.Windows.Forms.Label();
            this.filosofo2TE = new System.Windows.Forms.Label();
            this.filosofo2TD = new System.Windows.Forms.Label();
            this.filosofo2GD = new System.Windows.Forms.Label();
            this.filosofo3GE = new System.Windows.Forms.Label();
            this.filosofo3TE = new System.Windows.Forms.Label();
            this.filosofo3GD = new System.Windows.Forms.Label();
            this.filosofo3TD = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.imagem1 = new System.Windows.Forms.PictureBox();
            this.imagem2 = new System.Windows.Forms.PictureBox();
            this.imagem3 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.imagem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imagem2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imagem3)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(350, 194);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(88, 365);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 1;
            this.button2.Text = "button2";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(604, 365);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 2;
            this.button3.Text = "button3";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // filosofo1GE
            // 
            this.filosofo1GE.AutoSize = true;
            this.filosofo1GE.Location = new System.Drawing.Point(478, 204);
            this.filosofo1GE.Name = "filosofo1GE";
            this.filosofo1GE.Size = new System.Drawing.Size(35, 13);
            this.filosofo1GE.TabIndex = 3;
            this.filosofo1GE.Text = "label1";
            // 
            // filosofo1GD
            // 
            this.filosofo1GD.AutoSize = true;
            this.filosofo1GD.Location = new System.Drawing.Point(265, 204);
            this.filosofo1GD.Name = "filosofo1GD";
            this.filosofo1GD.Size = new System.Drawing.Size(35, 13);
            this.filosofo1GD.TabIndex = 4;
            this.filosofo1GD.Text = "label1";
            // 
            // filosofo1TE
            // 
            this.filosofo1TE.AutoSize = true;
            this.filosofo1TE.Location = new System.Drawing.Point(478, 228);
            this.filosofo1TE.Name = "filosofo1TE";
            this.filosofo1TE.Size = new System.Drawing.Size(35, 13);
            this.filosofo1TE.TabIndex = 5;
            this.filosofo1TE.Text = "label1";
            // 
            // filosofo1TD
            // 
            this.filosofo1TD.AutoSize = true;
            this.filosofo1TD.Location = new System.Drawing.Point(265, 228);
            this.filosofo1TD.Name = "filosofo1TD";
            this.filosofo1TD.Size = new System.Drawing.Size(35, 13);
            this.filosofo1TD.TabIndex = 6;
            this.filosofo1TD.Text = "label1";
            // 
            // filosofo2GE
            // 
            this.filosofo2GE.AutoSize = true;
            this.filosofo2GE.Location = new System.Drawing.Point(9, 375);
            this.filosofo2GE.Name = "filosofo2GE";
            this.filosofo2GE.Size = new System.Drawing.Size(35, 13);
            this.filosofo2GE.TabIndex = 7;
            this.filosofo2GE.Text = "label2";
            // 
            // filosofo2TE
            // 
            this.filosofo2TE.AutoSize = true;
            this.filosofo2TE.Location = new System.Drawing.Point(9, 399);
            this.filosofo2TE.Name = "filosofo2TE";
            this.filosofo2TE.Size = new System.Drawing.Size(35, 13);
            this.filosofo2TE.TabIndex = 8;
            this.filosofo2TE.Text = "label2";
            // 
            // filosofo2TD
            // 
            this.filosofo2TD.AutoSize = true;
            this.filosofo2TD.Location = new System.Drawing.Point(222, 399);
            this.filosofo2TD.Name = "filosofo2TD";
            this.filosofo2TD.Size = new System.Drawing.Size(35, 13);
            this.filosofo2TD.TabIndex = 9;
            this.filosofo2TD.Text = "label2";
            // 
            // filosofo2GD
            // 
            this.filosofo2GD.AutoSize = true;
            this.filosofo2GD.Location = new System.Drawing.Point(222, 375);
            this.filosofo2GD.Name = "filosofo2GD";
            this.filosofo2GD.Size = new System.Drawing.Size(35, 13);
            this.filosofo2GD.TabIndex = 10;
            this.filosofo2GD.Text = "label2";
            // 
            // filosofo3GE
            // 
            this.filosofo3GE.AutoSize = true;
            this.filosofo3GE.Location = new System.Drawing.Point(519, 375);
            this.filosofo3GE.Name = "filosofo3GE";
            this.filosofo3GE.Size = new System.Drawing.Size(35, 13);
            this.filosofo3GE.TabIndex = 11;
            this.filosofo3GE.Text = "label3";
            // 
            // filosofo3TE
            // 
            this.filosofo3TE.AutoSize = true;
            this.filosofo3TE.Location = new System.Drawing.Point(519, 399);
            this.filosofo3TE.Name = "filosofo3TE";
            this.filosofo3TE.Size = new System.Drawing.Size(35, 13);
            this.filosofo3TE.TabIndex = 12;
            this.filosofo3TE.Text = "label3";
            // 
            // filosofo3GD
            // 
            this.filosofo3GD.AutoSize = true;
            this.filosofo3GD.Location = new System.Drawing.Point(732, 375);
            this.filosofo3GD.Name = "filosofo3GD";
            this.filosofo3GD.Size = new System.Drawing.Size(35, 13);
            this.filosofo3GD.TabIndex = 13;
            this.filosofo3GD.Text = "label3";
            // 
            // filosofo3TD
            // 
            this.filosofo3TD.AutoSize = true;
            this.filosofo3TD.Location = new System.Drawing.Point(732, 399);
            this.filosofo3TD.Name = "filosofo3TD";
            this.filosofo3TD.Size = new System.Drawing.Size(35, 13);
            this.filosofo3TD.TabIndex = 14;
            this.filosofo3TD.Text = "label3";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(242, 352);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(15, 13);
            this.label1.TabIndex = 15;
            this.label1.Text = "D";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(265, 181);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(15, 13);
            this.label2.TabIndex = 16;
            this.label2.Text = "D";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(753, 352);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(15, 13);
            this.label3.TabIndex = 17;
            this.label3.Text = "D";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(9, 352);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(14, 13);
            this.label4.TabIndex = 18;
            this.label4.Text = "E";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(519, 352);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(14, 13);
            this.label5.TabIndex = 19;
            this.label5.Text = "E";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(499, 181);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(14, 13);
            this.label6.TabIndex = 20;
            this.label6.Text = "E";
            // 
            // imagem1
            // 
            this.imagem1.ImageLocation = "";
            this.imagem1.Location = new System.Drawing.Point(268, 12);
            this.imagem1.Name = "imagem1";
            this.imagem1.Size = new System.Drawing.Size(245, 162);
            this.imagem1.TabIndex = 21;
            this.imagem1.TabStop = false;
            // 
            // imagem2
            // 
            this.imagem2.Location = new System.Drawing.Point(12, 183);
            this.imagem2.Name = "imagem2";
            this.imagem2.Size = new System.Drawing.Size(245, 162);
            this.imagem2.TabIndex = 22;
            this.imagem2.TabStop = false;
            // 
            // imagem3
            // 
            this.imagem3.Location = new System.Drawing.Point(522, 183);
            this.imagem3.Name = "imagem3";
            this.imagem3.Size = new System.Drawing.Size(245, 162);
            this.imagem3.TabIndex = 23;
            this.imagem3.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(780, 421);
            this.Controls.Add(this.imagem3);
            this.Controls.Add(this.imagem2);
            this.Controls.Add(this.imagem1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.filosofo3TD);
            this.Controls.Add(this.filosofo3GD);
            this.Controls.Add(this.filosofo3TE);
            this.Controls.Add(this.filosofo3GE);
            this.Controls.Add(this.filosofo2GD);
            this.Controls.Add(this.filosofo2TD);
            this.Controls.Add(this.filosofo2TE);
            this.Controls.Add(this.filosofo2GE);
            this.Controls.Add(this.filosofo1TD);
            this.Controls.Add(this.filosofo1TE);
            this.Controls.Add(this.filosofo1GD);
            this.Controls.Add(this.filosofo1GE);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.imagem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imagem2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imagem3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label filosofo1GE;
        private System.Windows.Forms.Label filosofo1GD;
        private System.Windows.Forms.Label filosofo1TE;
        private System.Windows.Forms.Label filosofo1TD;
        private System.Windows.Forms.Label filosofo2GE;
        private System.Windows.Forms.Label filosofo2TE;
        private System.Windows.Forms.Label filosofo2TD;
        private System.Windows.Forms.Label filosofo2GD;
        private System.Windows.Forms.Label filosofo3GE;
        private System.Windows.Forms.Label filosofo3TE;
        private System.Windows.Forms.Label filosofo3GD;
        private System.Windows.Forms.Label filosofo3TD;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.PictureBox imagem1;
        private System.Windows.Forms.PictureBox imagem2;
        private System.Windows.Forms.PictureBox imagem3;
    }
}

